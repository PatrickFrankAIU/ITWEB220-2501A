// this version uses fetch with async/await
// advantage: No promise chain handler, but instead needs a try/catch block
// - Promise chains are standard and clear, very readable
// - Async/Await supports more complex logic, like multiple async steps
//   (no "promise chain hell")

window.addEventListener("DOMContentLoaded", function () {
    document.querySelector("#fetchQuotesBtn").addEventListener("click", function () {
        // Get values from drop-downs
        const topicDropdown = document.querySelector("#topicSelection");
        const selectedTopic = topicDropdown.options[topicDropdown.selectedIndex].value;

        const countDropdown = document.querySelector("#countSelection");
        const selectedCount = countDropdown.options[countDropdown.selectedIndex].value;

        // Get and display quotes using async/await
        fetchQuotes(selectedTopic, selectedCount);
    });
});

async function fetchQuotes(topic, count) {
    const endpoint = "https://wp.zybooks.com/quotes.php";
    const queryString = "topic=" + topic + "&count=" + count; 
    const url = endpoint + "?" + queryString;

    try {
        // Perform the fetch request
        const response = await fetch(url);

        if (!response.ok) {
            // Throw an error if we didn't get a 200-299 status
            throw new Error(); // again unlikely to do anything (could put a msg in the parens)
        }

        // Parse the response as JSON
        const data = await response.json();
        const quoteDiv = document.getElementById("quotes");

        if (data.error) {
            // Handle any error returned by the server
            quoteDiv.innerHTML = data.error;
        } else {
            // Build the HTML list of quotes
            let html = "<ol>";
            data.forEach((quoteItem) => {
				html += '<li>' + quoteItem.quote + ' - ' + quoteItem.source + '</li>';
            });
            html += "</ol>";
            quoteDiv.innerHTML = html;
        }
    } catch (error) {
        // Handle network or fetch-related errors
        const quoteDiv = document.getElementById("quotes");
        quoteDiv.innerHTML = "Quote is unavailable.";
        console.error("Problem during fetch:", error);
    }
}


/*
Notes: 
- Show what happens if you remove async and both of the await commands
  - Should fail with error message
  - This is because the Fetch isn't waiting for the response to be fully retrieved before moving on to
    the next line of code. So it tries to handle a response before it's available, resulting in an error. 
*/