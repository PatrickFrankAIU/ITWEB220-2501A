// this version uses Promises and Fetch
// does not use async/await (instead uses a promise chain provided by Fetch (.then & .catch))
// more modern approach, more standardized
// simpler, cleaner, easier to read
// better error handling

window.addEventListener("DOMContentLoaded", function () {
    document.querySelector("#fetchQuotesBtn").addEventListener("click", function () {
        // Get values from drop-downs
        const topicDropdown = document.querySelector("#topicSelection");
        const selectedTopic = topicDropdown.options[topicDropdown.selectedIndex].value;
        const countDropdown = document.querySelector("#countSelection");
        const selectedCount = countDropdown.options[countDropdown.selectedIndex].value;
    
        // Get and display quotes using fetch API
        fetchQuotes(selectedTopic, selectedCount);
    });
});

function fetchQuotes(topic, count) {
    const endpoint = "https://wp.zybooks.com/quotes.php"; 
	//const endpoint = "https://example.com/api/quotes"; // bad URL for testing 
    const queryString = "topic=" + topic + "&count=" + count; 
    const url = endpoint + "?" + queryString;

    fetch(url) // standard browser function, part of Web API (defined by same org as DOM)
        // the fetch call above returns a promise, so we have to handle that with .then
        .then(response => {
            if (!response.ok) { // this probably won't do anything because the PHP app is handling errors
                throw new Error();  // (it's providing "OK" responses to bad queries and passing the error)
            }                       // Note: Could put a msg in the parens if useful
            return response.json();
        })
        .then(data => {
            const quoteDiv = document.getElementById("quotes");
            if (data.error) {
                quoteDiv.innerHTML = data.error;
            } else {
                let html = "<ol>";
                data.forEach(quoteItem => {
                    html += "<li>" + quoteItem.quote + " - " + quoteItem.source + "</li>";
                });
                html += "</ol>";
                quoteDiv.innerHTML = html;
            }
        })
		// could add more .then() here to process the data, or to nest fetch requests
        .catch(error => {
            const quoteDiv = document.getElementById("quotes");
            quoteDiv.innerHTML = "Quote is unavailable.";
            console.error("There was a problem with the fetch operation:", error);
        });
}


// trigger the !response.ok error by changing the endpoint variable to the "bad" URL
//   show this with breakpoint debug to show that debugging async code can be challenging 
//   (it may not highlight those lines while debugging)
