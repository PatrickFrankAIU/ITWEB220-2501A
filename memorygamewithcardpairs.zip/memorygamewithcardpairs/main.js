// Define the game logic
const cards = [
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', // Pairs of cards
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'
];
let flippedCards = []; // Store flipped cards
let matchedCards = 0;  // Track number of matched pairs

// Shuffle cards using Fisher-Yates algorithm aka "Knuth Shuffle" (from his book)
/* starts with last index (hence the -1) and counts down to 1
- works by selecting a random index and swapping it with the current element
- working backwards avoids revisiting already shuffled elements
- math.random() * (i + 1): scales number to a value between 0 and i, giving a
  random index within the given range 
- math.floor() rounds the result down to the nearest integer
  (ensures that j is a valid array index)
- [array[i],... (etc) is a "desctructuring assignment" swapping array[i] & array[j]
  - left side accesses the elements, right side switches their values
- Why it works: At each step of the loop, the algorithm picks a random 
  index j (from 0 to i) and swaps the element at index i with the element 
  at index j. By the time the loop finishes, every element has been shuffled 
  with a random other element, resulting in a uniformly shuffled array.
- Runs in O(n) time where n is the number of elements in the array; iterates 
  over each element in the array exactly once 
- Space complexity: "in place", meaning this alg doesn't create a temporary 
  array (though the larger program does do that to store game progress)
*/
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

// Initialize game board with cards
function createGameBoard() {
    shuffle(cards); // Shuffle cards before displaying
    const gameBoard = document.getElementById('game-board');
    gameBoard.innerHTML = ''; // Clear the board if it's already populated

    cards.forEach((cardValue, index) => {
        const cardElement = document.createElement('div');
        cardElement.classList.add('card');
        cardElement.dataset.cardValue = cardValue;
        cardElement.addEventListener('click', flipCard);
        gameBoard.appendChild(cardElement);
    });
}

// Flip card function
function flipCard() {
    const card = this;

    // Ignore if card is already flipped or matched
    if (flippedCards.length === 2 || card.classList.contains('flipped') || card.classList.contains('matched')) {
        return;
    }

    card.classList.add('flipped');
    card.textContent = card.dataset.cardValue;
    flippedCards.push(card);

    // Check if two cards are flipped
    if (flippedCards.length === 2) {
        checkMatch();
    }
}

// Check if the two flipped cards match
function checkMatch() {
    const [card1, card2] = flippedCards;

    if (card1.dataset.cardValue === card2.dataset.cardValue) {
        // If matched
        card1.classList.add('matched');
        card2.classList.add('matched');
        matchedCards++;

        // Check if all pairs are matched
        if (matchedCards === cards.length / 2) {
            setTimeout(() => {
                alert('You won!');
            }, 500);
        }
    } else {
        // If not matched, flip cards back after a short delay
        setTimeout(() => {
            card1.classList.remove('flipped');
            card2.classList.remove('flipped');
            card1.textContent = '';
            card2.textContent = '';
        }, 1000);
    }

    // Reset flipped cards array
    flippedCards = [];
}

// Initialize the game when the page loads
createGameBoard();
