// Array of photo objects with category and image URL
const photos = [
    { category: 'nature', url: 'https://picsum.photos/150/150?random=1' },
    { category: 'nature', url: 'https://picsum.photos/150/150?random=2' },
    { category: 'animals', url: 'https://picsum.photos/150/150?random=3' },
    { category: 'animals', url: 'https://picsum.photos/150/150?random=4' },
    { category: 'architecture', url: 'https://picsum.photos/150/150?random=5' },
    { category: 'architecture', url: 'https://picsum.photos/150/150?random=6' }
];

// Function to display images based on the selected category
function displayGallery(filter) {
    const gallery = document.getElementById('gallery');
    gallery.innerHTML = ''; // Clear the gallery before updating

    // Filter photos based on selected category
    let filteredPhotos;
    
    if (filter === 'all') {
        filteredPhotos = photos; // Show all photos if 'all' is selected
    } else {
        filteredPhotos = photos.filter(photo => photo.category === filter); // Filter by category
    }

    // Display each photo
    filteredPhotos.forEach(photo => {
        const img = document.createElement('img');
        img.src = photo.url;
        img.alt = photo.category;
        gallery.appendChild(img);
    });
}

// Handle filter change
document.getElementById('filter').addEventListener('change', (event) => {
    displayGallery(event.target.value);
});

// Initial display with all photos
displayGallery('all');
